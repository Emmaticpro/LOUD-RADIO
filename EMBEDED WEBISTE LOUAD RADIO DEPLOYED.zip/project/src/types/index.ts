export interface DJ {
  id: number;
  name: string;
  image: string;
  bio: string;
  showTimes: string[];
  socialLinks: {
    twitter?: string;
    instagram?: string;
    facebook?: string;
  };
}

export interface Show {
  id: number;
  title: string;
  description: string;
  dj: number; // DJ ID
  day: string;
  startTime: string;
  endTime: string;
  image?: string;
}

export interface NewsItem {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  date: string;
  author: string;
}

export interface Track {
  id: number;
  title: string;
  artist: string;
  album?: string;
  coverImage: string;
  position: number;
  lastPosition?: number;
}