import React, { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import AudioPlayer from './components/AudioPlayer';
import CurrentShow from './components/CurrentShow';
import Schedule from './components/Schedule';
import DJProfiles from './components/DJProfiles';
import News from './components/News';
import Charts from './components/Charts';
import Contact from './components/Contact';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';
import { currentShow } from './data/mockData';

function App() {
  useEffect(() => {
    // Update document title
    document.title = "Loud Radio - Your Source Your Hits";
    
    // Change favicon (optional)
    const link = document.querySelector("link[rel='icon']") as HTMLLinkElement;
    if (link) {
      link.href = 'https://images.pexels.com/photos/9618613/pexels-photo-9618613.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    }
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section id="home">
        <Hero />
      </section>
      
      {/* Audio Player - Fixed to bottom */}
      <div className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-4">
        <AudioPlayer />
      </div>
      
      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        {/* Current Show */}
        <div className="mb-16">
          <CurrentShow 
            title={currentShow.title} 
            dj={currentShow.dj} 
            currentTrack={currentShow.currentTrack} 
          />
        </div>
        
        {/* Schedule */}
        <section id="schedule" className="mb-16">
          <Schedule />
        </section>
        
        {/* DJs */}
        <section id="djs" className="mb-16">
          <DJProfiles />
        </section>
        
        {/* News */}
        <section id="news" className="mb-16">
          <News />
        </section>
        
        {/* Charts */}
        <section id="charts" className="mb-16">
          <Charts />
        </section>
        
        {/* Newsletter */}
        <section className="mb-16">
          <Newsletter />
        </section>
        
        {/* Contact */}
        <section id="contact" className="mb-16">
          <Contact />
        </section>
      </div>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;