import { DJ, Show, NewsItem, Track } from '../types';

export const djs: DJ[] = [
  {
    id: 1,
    name: "DJ IVANISH & MC ECHO",
    image: "https://i.postimg.cc/sfkWx57h/Morning-Moods.jpg",
    bio: "Dj Ivanish & Mc Echo is our morning show host with over 3 years of experience in radio. Known for high energy and witty commentary.",
    showTimes: ["Weekdays 6AM - 10AM"],
    socialLinks: {
      twitter: "https://twitter.com/djivanish256",
      instagram: "https://instagram.com/djivanish256",
      facebook: "https://facebook.com/djivanish256"
    }
  },
  {
    id: 2,
    name: "Emmatic Pro Mr.Vibes,Mc Swagg, Babe Gal",
    image: "https://i.postimg.cc/MZMRz9Mw/Emmatic1.jpg",
    bio: "These hosts our Mid Morning Blaze | Mix at 10am and brings the latest hits and celebrity gossip to your commute home.",
    showTimes: ["Weekdays 10:00AM - 12:00AM"],
    socialLinks: {
      twitter: "https://twitter.com/Mid Morning Blaze",
      instagram: "https://instagram.com/Mid Morning Blaze"
    }
  },
  {
    id: 3,
    name: "Gen. Silver",
    image: "https://i.postimg.cc/W1jJ6j9p/silver.jpg" ,
    bio: "Gen Silver is our presenter for the Mid Morning Loud Request, mixing the best beats and keeping you dancing all night long.",
    showTimes: ["Weekdays 12:00AM - 2:00PM", "Saturday 12:00AM - 3:00PM"],
    socialLinks: {
      instagram: "https://instagram.com/",
      facebook: "https://facebook.com/Loud Radio"
    }
  },
  {
    id: 4,
    name: "Sula Boy ",
    image: "https://i.postimg.cc/KY9NHQjW/IMG-20240927-WA0279.jpg",
    bio: "Sula Boy brings you the Hot on Spot News.",
    showTimes: ["Saturday & Sunday 12PM - 4PM"],
    socialLinks: {
      twitter: "https://twitter.com/Loud Radio",
      instagram: "https://instagram.com/Loud Radio"
    }
  }
];

export const shows: Show[] = [
  {
    id: 1,
    title: "Morning Moods",
    description: "Dj Ivanish & Mc Echo and get your day started with the hottest tracks, celebrity gossip, and engaging discussions.",
    dj: 1,
    day: "Weekdays",
    startTime: "06:00am",
    endTime: "10:00am",
    image: "https://i.postimg.cc/sfkWx57h/Morning-Moods.jpg"
  },
  {
    id: 2,
    title: "Loud Request",
    description: "Take your Loud Request  with us as we play non-stop hits to energize your afternoon.",
    dj: 2,
    day: "Weekdays",
    startTime: "12:00noon ",
    endTime: "2:00pm",
    image: "https://i.postimg.cc/prncHgpQ/Loud-Request.jpg"
  },
  {
    id: 3,
    title: "Exclusive Evening M!C",
    description: "Join Exclusive Evening M!C for your commute home with traffic updates, latest hits, and call-in contests.",
    dj: 2,
    day: "Weekdays",
    startTime: "3:00PM ",
    endTime: "6:00PM",
    image: "https://i.postimg.cc/QxcTTVJn/exclusive-Evening.jpg"
  },
  {
    id: 4,
    title: "Blaze Music",
    description: "Dj Phantomic you the best electronic, dance, and hip-hop tracks to keep your evening lively.",
    dj: 3,
    day: "Weekdays",
    startTime: "6:00PM ",
    endTime: "7:00PM",
    image: "https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 5,
    title: "Top 10 Countdown",
    description: "Babe Gal brings you the hottest 10 Songs of the day on Loud Radio.",
    dj: 4,
    day: "Weekend",
    startTime: "7:00PM ",
    endTime: "8:00PM",
    image: "https://images.pexels.com/photos/2111015/pexels-photo-2111015.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 6,
    title: "Business Yoo",
    description: "We Bring You Business Ideas and Guest to teach you about Business.",
    dj: 3,
    day: "Saturday",
    startTime: "8:00PM ",
    endTime: "9:00PM",
    image: "https://i.postimg.cc/0y4GGj4g/global-business-logistics-import-export-background-container-cargo-freight-ship-transport-concept-13.webp"
  }
];

export const news: NewsItem[] = [
  {
    id: 1,
    title: "Frank Gashumba: Bobi Wine stands out as Uganda’s only international celebrity",
    excerpt: "Outspoken social and political analyst Frank Gashumba has revealed that Afro-pop singer-cum-politician Robert Kyagulanyi alias Bobi Wine is the only Ugandan musician with an international celebrity status.",
    content: "He explained that he also managed to secure the status because of his involvement in national politics as the leader of the most popular opposition political party the National Unity Platform (NUP).",
    image: "https://i.postimg.cc/V6QNwc48/bobi.webp",
    date: "2025-07-07",
    author: "Loud Radio Team"
  },
  {
    id: 2,
    title: "Ilai Residence",
    excerpt: "Home Away From Home A place to Rest Location Nyenje Mukono.",
    content: "Affordable prices with Nice View, meals and services. Call Us on 0772502009 or 0702622635",
    image: "https://i.postimg.cc/QCNvvwzH/M-1.jpg",
    date: "2025-07-07",
    author: "Peoples Eye Emmatic Pro"
  },
  {
    id: 3,
    title: "Dax Vibes & Mikie Wine Arrested in Jinja",
    excerpt: "Singers Dax Vibez and Mikie Wine were reportedly arrested while on their way from Jinja in the wee hours of Monday morning.",
    content: "According to reports, Mikie Wine and Dax Vibez – both brothers of NUP president, Bobi Wine – were intercepted by Police at around 2 AM in Jinja. The circumstances surrounding their arrest remain unclear, but sources suggest it may be related to their recent political activities. Both artists have been vocal supporters of opposition politics in Uganda.",
    image: "https://i.postimg.cc/MHRdgznQ/photo-output-6-edited-scaled.webp",
    date: "2025-07-07",
    author: "Loud Radio Team"
  },
  {
    id: 4,
    title: "Emmatic Pro 2 Days Carnival Success",
    excerpt: "The highly anticipated Emmatic Pro 2 Days Carnival concluded with massive success despite initial challenges.",
    content: "The event, which took place over the weekend, attracted thousands of music lovers from across the region. Despite facing logistical challenges, organizers managed to deliver an unforgettable experience featuring top local and international artists. Emmatic Pro has announced plans for another carnival at Summer Garden Mukono, with dates to be communicated soon.",
    image: "https://i.postimg.cc/G2Nykyf6/banner-carnival.jpg",
    date: "2025-07-07",
    author: "Loud Radio Team"
  },
  {
    id: 5,
    title: "New Music Releases This Week",
    excerpt: "Check out the hottest new tracks that have been added to our playlist rotation.",
    content: "This week brings exciting new releases from both established and emerging artists. From Acidic Vocals's latest hit 'Come To Daddy'",
    image: "https://i.postimg.cc/9XvkbnD9/i-love-you-by-acidic-vokoz-free-mp3-download.jpg",
    date: "2025-07-07",
    author: "Music Team"
  },
  {
    id: 6,
    title: "Loud Radio Community Outreach Program",
    excerpt: "We're giving back to the community through our new outreach initiative in Mukono.",
    content: "Loud Radio is proud to announce our community outreach program aimed at supporting local schools and youth organizations in Mukono. The program includes educational workshops, music equipment donations, and mentorship opportunities for aspiring young broadcasters and musicians. We believe in nurturing the next generation of talent in our community.",
    image: "https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    date: "2025-07-07",
    author: "Community Relations Team"
  }
];

export const tracks: Track[] = [
  {
    id: 1,
    title: "Come To Daddy",
    artist: "Acidic Vocals",
    album: "Acidic Music",
    coverImage: "https://i.postimg.cc/9XvkbnD9/i-love-you-by-acidic-vokoz-free-mp3-download.jpg",
    position: 1,
    lastPosition: 2
  },
  {
    id: 2,
    title: "Kaba",
    artist: "Kapeke",
    album: "Kapeke Music",
    coverImage: "https://i.postimg.cc/3r9nkrGn/Kapeke-edited.webp",
    position: 2,
    lastPosition: 1
  },
  {
    id: 3,
    title: "TikTok Live",
    artist: "King Saha",
    album: "Nakyakala",
    coverImage: "https://i.postimg.cc/L8g2X0Kt/yama-1744143481.webp",
    position: 3,
    lastPosition: 5
  },
  {
    id: 4,
    title: "Kankutendereze Remix",
    artist: "King Saha",
    album: "2025",
    coverImage: "https://i.postimg.cc/JtVjXJ4y/ensi-yaffe-by-king-saha-free-mp3-download.jpg",
    position: 4,
    lastPosition: 3
  },
  {
    id: 5,
    title: "Bilalamu",
    artist: "Fik Fameica",
    coverImage: "https://i.postimg.cc/hjtKcPxN/fik.webp",
    position: 5,
    lastPosition: 4
  },
  {
    id: 6,
    title: "Balumye",
    artist: "Friction Vanlee",
    album: "Tebansobola",
    coverImage: "https://i.postimg.cc/bwTSmMMx/LOGO-HEAD-FRICTION-VANLEE.png",
    position: 6,
    lastPosition: 6
  },
  {
    id: 7,
    title: "Loose Control",
    artist: "Mimim Kampala",
    album: "Mimi Music",
    coverImage: "https://i.postimg.cc/sgx8jQ0Y/mimi-kampala.jpg",
    position: 7,
    lastPosition: 7
  },
  {
    id: 8,
    title: "Berawo",
    artist: "Sasa Rogan",
    album: "Elite Music",
    coverImage: "https://i.postimg.cc/wx7Z5RM2/BERAWO-3000-X-3000px.jpg",
    position: 8,
    lastPosition: 10
  },
  {
    id: 9,
    title: "Angonza",
    artist: "Vyroota",
    album: "Vyroota Music",
    coverImage: "https://i.postimg.cc/d1ZwLNH9/vyroota.jpg",
    position: 9,
    lastPosition: 8
  },
  {
    id: 10,
    title: "Simububi",
    artist: "Romantic Guy",
    album: "Simububi",
    coverImage: "https://i.postimg.cc/wvHxycgw/SIMUBUBI-POSTER-AUDIO-OUT.jpg",
    position: 10,
    lastPosition: 9
  }
];

export const currentShow = {
  id: 1,
  title: "Morning Moods",
  dj: djs[0],
  currentTrack: tracks[0]
};