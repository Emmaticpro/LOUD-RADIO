import React from 'react';
import { Radio, Play } from 'lucide-react';

const Hero: React.FC = () => {
  const handlePlayClick = () => {
    const audioPlayerButton = document.querySelector('[aria-label="Play"]') as HTMLButtonElement;
    if (audioPlayerButton) {
      audioPlayerButton.click();
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-purple-900">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://i.postimg.cc/3JdCWXYx/LOUD-SAKATA-BLACK.jpg"
          alt="Radio studio background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/90 to-pink-600/80"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10 text-white text-center">
        <div className="flex justify-center items-center mb-6">
          <h1 className="text-5xl md:text-7xl font-extrabold ml-4">
            Loud<span className="text-pink-500">Radio</span>
          </h1>
        </div>
        
        <h2 className="text-xl md:text-3xl font-light mb-8 max-w-3xl mx-auto">
          Sakata - Broadcasting the Best Beats 24/7
        </h2>
        
        <div className="flex flex-col md:flex-row gap-4 justify-center mb-12">
          <button 
            onClick={handlePlayClick}
            className="bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-6 rounded-full transition-colors flex items-center justify-center"
          >
            <Play size={20} className="mr-2" />
            Listen Live
          </button>
          <button className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white font-bold py-3 px-6 rounded-full border border-white/30 transition-colors">
            View Schedule
          </button>
        </div>
        
        <div className="inline-block bg-white/10 backdrop-blur-sm px-6 py-3 rounded-full border border-white/30">
          <span className="font-mono text-xl md:text-2xl font-bold">Live Stream</span>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="w-full h-auto">
          <path fill="#ffffff" fillOpacity="1" d="M0,288L48,272C96,256,192,224,288,218.7C384,213,480,235,576,234.7C672,235,768,213,864,208C960,203,1056,213,1152,229.3C1248,245,1344,267,1392,277.3L1440,288L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
      </div>
    </div>
  );
};

export default Hero;