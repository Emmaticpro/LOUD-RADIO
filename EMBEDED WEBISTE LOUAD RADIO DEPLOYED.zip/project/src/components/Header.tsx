import React, { useState, useEffect } from 'react';
import { Radio, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };
  
  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-purple-900 shadow-lg py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
           {/* Logo Image */}
        

           
        
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection('home')}
              className="text-white hover:text-pink-400 transition-colors"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('schedule')}
              className="text-white hover:text-pink-400 transition-colors"
            >
              Schedule
            </button>
            <button 
              onClick={() => scrollToSection('djs')}
              className="text-white hover:text-pink-400 transition-colors"
            >
              Our Presenters
            </button>
            <button 
              onClick={() => scrollToSection('news')}
              className="text-white hover:text-pink-400 transition-colors"
            >
              News
            </button>
            <button 
              onClick={() => scrollToSection('charts')}
              className="text-white hover:text-pink-400 transition-colors"
            >
              Charts
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="text-white hover:text-pink-400 transition-colors"
            >
              Contact
            </button>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white focus:outline-none"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 py-4 border-t border-purple-800">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('home')}
                className="text-white hover:text-pink-400 transition-colors py-2"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('schedule')}
                className="text-white hover:text-pink-400 transition-colors py-2"
              >
                Schedule
              </button>
              <button 
                onClick={() => scrollToSection('djs')}
                className="text-white hover:text-pink-400 transition-colors py-2"
              >
                Our Presenters
              </button>
              <button 
                onClick={() => scrollToSection('news')}
                className="text-white hover:text-pink-400 transition-colors py-2"
              >
                News
              </button>
              <button 
                onClick={() => scrollToSection('charts')}
                className="text-white hover:text-pink-400 transition-colors py-2"
              >
                Charts
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="text-white hover:text-pink-400 transition-colors py-2"
              >
                Contact
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;