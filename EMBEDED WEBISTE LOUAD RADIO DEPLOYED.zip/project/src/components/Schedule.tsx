import React, { useState } from 'react';
import { shows } from '../data/mockData';
import { Calendar, Clock } from 'lucide-react';

const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

const Schedule: React.FC = () => {
  const [activeDay, setActiveDay] = useState<string>("Weekdays");
  
  const filteredShows = shows.filter(show => 
    show.day === activeDay || 
    (activeDay === "Weekdays" && ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].includes(show.day)) ||
    (activeDay === "Weekend" && ["Saturday", "Sunday"].includes(show.day))
  );

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-gradient-to-r from-purple-800 to-pink-500 p-4 text-white">
        <h2 className="font-bold text-xl flex items-center">
          <Calendar size={20} className="mr-2" />
          Program Schedule
        </h2>
      </div>
      
      <div className="p-4">
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setActiveDay("Weekdays")}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              activeDay === "Weekdays" 
                ? "bg-purple-900 text-white" 
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            Weekdays
          </button>
          <button
            onClick={() => setActiveDay("Weekend")}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              activeDay === "Weekend" 
                ? "bg-purple-900 text-white" 
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            Weekend
          </button>
          {daysOfWeek.map(day => (
            <button
              key={day}
              onClick={() => setActiveDay(day)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeDay === day 
                  ? "bg-purple-900 text-white" 
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {day}
            </button>
          ))}
        </div>
        
        <div className="space-y-4">
          {filteredShows.length > 0 ? (
            filteredShows.map(show => (
              <div key={show.id} className="border border-gray-200 rounded-lg overflow-hidden flex flex-col md:flex-row hover:shadow-md transition-shadow">
                {show.image && (
                  <div className="md:w-1/4">
                    <img 
                      src={show.image} 
                      alt={show.title} 
                      className="w-full h-40 md:h-full object-cover"
                    />
                  </div>
                )}
                <div className={`p-4 ${show.image ? 'md:w-3/4' : 'w-full'}`}>
                  <h3 className="text-xl font-bold text-purple-900">{show.title}</h3>
                  <div className="flex items-center mt-2 text-gray-600">
                    <Clock size={16} className="mr-2" />
                    <span>{show.startTime} - {show.endTime}</span>
                  </div>
                  <p className="mt-2 text-gray-700">{show.description}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-gray-500">
              No shows scheduled for this day.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Schedule;