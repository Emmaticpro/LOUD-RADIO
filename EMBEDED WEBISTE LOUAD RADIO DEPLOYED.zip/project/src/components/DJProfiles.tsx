import React, { useState } from 'react';
import { djs } from '../data/mockData';
import { Users, Clock, Instagram, Twitter, Facebook } from 'lucide-react';

const DJProfiles: React.FC = () => {
  const [activeDJ, setActiveDJ] = useState<number | null>(null);
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-gradient-to-r from-purple-800 to-pink-500 p-4 text-white">
        <h2 className="font-bold text-xl flex items-center">
          <Users size={20} className="mr-2" />
          Meet Our Presenters
        </h2>
      </div>
      
      <div className="p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {djs.map(dj => (
            <div 
              key={dj.id}
              onClick={() => setActiveDJ(dj.id === activeDJ ? null : dj.id)}
              className={`rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer border-2 ${
                dj.id === activeDJ ? 'border-purple-500' : 'border-transparent'
              }`}
            >
              <img 
                src={dj.image} 
                alt={dj.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-3 text-center">
                <h3 className="font-bold text-lg text-purple-900">{dj.name}</h3>
              </div>
            </div>
          ))}
        </div>
        
        {activeDJ !== null && (
          <div className="border-t border-gray-200 pt-4 animate-fadeIn">
            {djs
              .filter(dj => dj.id === activeDJ)
              .map(dj => (
                <div key={dj.id} className="flex flex-col md:flex-row gap-6">
                  <div className="md:w-1/3">
                    <img 
                      src={dj.image} 
                      alt={dj.name}
                      className="w-full h-60 object-cover rounded-lg shadow-md"
                    />
                    
                    <div className="mt-4 flex justify-center gap-4">
                      {dj.socialLinks.twitter && (
                        <a 
                          href={dj.socialLinks.twitter} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-purple-900 hover:text-purple-700 transition-colors"
                          aria-label={`${dj.name}'s Twitter`}
                        >
                          <Twitter size={24} />
                        </a>
                      )}
                      {dj.socialLinks.instagram && (
                        <a 
                          href={dj.socialLinks.instagram} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-purple-900 hover:text-purple-700 transition-colors"
                          aria-label={`${dj.name}'s Instagram`}
                        >
                          <Instagram size={24} />
                        </a>
                      )}
                      {dj.socialLinks.facebook && (
                        <a 
                          href={dj.socialLinks.facebook} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-purple-900 hover:text-purple-700 transition-colors"
                          aria-label={`${dj.name}'s Facebook`}
                        >
                          <Facebook size={24} />
                        </a>
                      )}
                    </div>
                  </div>
                  <div className="md:w-2/3">
                    <h3 className="text-2xl font-bold text-purple-900 mb-2">{dj.name}</h3>
                    <div className="mb-4">
                      {dj.showTimes.map((time, index) => (
                        <div key={index} className="flex items-center text-gray-600 mt-1">
                          <Clock size={16} className="mr-2" />
                          <span>{time}</span>
                        </div>
                      ))}
                    </div>
                    <p className="text-gray-700 leading-relaxed">{dj.bio}</p>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DJProfiles;