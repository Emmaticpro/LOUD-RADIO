import React from 'react';
import { tracks } from '../data/mockData';
import { TrendingUp, ChevronUp, ChevronDown, Minus } from 'lucide-react';

const Charts: React.FC = () => {
  const getPositionIcon = (track: any) => {
    if (!track.lastPosition) return <Minus size={16} className="text-gray-400" />;
    
    if (track.position < track.lastPosition) {
      return <ChevronUp size={16} className="text-green-500" />;
    } else if (track.position > track.lastPosition) {
      return <ChevronDown size={16} className="text-red-500" />;
    } else {
      return <Minus size={16} className="text-gray-400" />;
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-gradient-to-r from-purple-800 to-pink-500 p-4 text-white">
        <h2 className="font-bold text-xl flex items-center">
          <TrendingUp size={20} className="mr-2" />
          Top 10 Count Down
        </h2>
      </div>
      
      <div className="p-4">
        <div className="overflow-hidden">
          {tracks.map(track => (
            <div 
              key={track.id}
              className="flex items-center p-3 border-b border-gray-100 hover:bg-purple-50 transition-colors"
            >
              <div className="w-10 flex justify-center font-bold text-lg text-purple-900">
                {track.position}
              </div>
              <div className="w-6 flex justify-center">
                {getPositionIcon(track)}
              </div>
              <div className="flex-shrink-0 w-12 h-12 mx-3">
                <img 
                  src={track.coverImage} 
                  alt={track.title}
                  className="w-full h-full object-cover rounded"
                />
              </div>
              <div className="flex-grow">
                <h3 className="font-medium text-gray-800">{track.title}</h3>
                <p className="text-sm text-gray-600">{track.artist}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Charts;