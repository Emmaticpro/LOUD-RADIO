import React from 'react';
import { Clock, User } from 'lucide-react';
import { DJ, Track } from '../types';

interface CurrentShowProps {
  title: string;
  dj: DJ;
  currentTrack?: Track;
}

const CurrentShow: React.FC<CurrentShowProps> = ({ title, dj, currentTrack }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-gradient-to-r from-purple-800 to-pink-500 p-4 text-white">
        <h2 className="font-bold text-xl">Now Playing</h2>
      </div>
      <div className="p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="md:w-1/3">
            <img 
              src={dj.image} 
              alt={dj.name}
              className="w-full h-48 object-cover rounded-md shadow-sm"
            />
          </div>
          <div className="md:w-2/3">
            <h3 className="text-2xl font-bold text-purple-900">{title}</h3>
            <div className="flex items-center mt-2 text-gray-600">
              <User size={18} className="mr-2" />
              <span className="font-medium">{dj.name}</span>
            </div>
            <div className="flex items-center mt-1 text-gray-600">
              <Clock size={18} className="mr-2" />
              <span>{dj.showTimes[0]}</span>
            </div>
            <p className="mt-3 text-gray-700">{dj.bio}</p>
          </div>
        </div>
        
        {currentTrack && (
          <div className="mt-6 border-t border-gray-200 pt-4">
            <h4 className="font-semibold text-gray-800">Currently Playing:</h4>
            <div className="flex items-center mt-2">
              <img 
                src={currentTrack.coverImage} 
                alt={`${currentTrack.title} by ${currentTrack.artist}`}
                className="w-16 h-16 object-cover rounded shadow-sm"
              />
              <div className="ml-4">
                <p className="font-medium text-purple-900">{currentTrack.title}</p>
                <p className="text-gray-600">{currentTrack.artist}</p>
                {currentTrack.album && <p className="text-sm text-gray-500">{currentTrack.album}</p>}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CurrentShow;