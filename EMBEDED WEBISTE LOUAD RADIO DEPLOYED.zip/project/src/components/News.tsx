import React, { useState } from 'react';
import { news } from '../data/mockData';
import { ScrollText, Calendar } from 'lucide-react';

const News: React.FC = () => {
  const [activeNewsItem, setActiveNewsItem] = useState<number | null>(null);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-gradient-to-r from-purple-800 to-pink-500 p-4 text-white">
        <h2 className="font-bold text-xl flex items-center">
          <ScrollText size={20} className="mr-2" />
          Latest News
        </h2>
      </div>
      
      <div className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {news.map(item => (
            <div 
              key={item.id}
              className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
            >
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="font-bold text-lg text-purple-900 line-clamp-2">{item.title}</h3>
                <div className="flex items-center mt-2 text-gray-500 text-sm">
                  <Calendar size={14} className="mr-1" />
                  <span>{formatDate(item.date)}</span>
                </div>
                <p className="mt-2 text-gray-600 line-clamp-3">{item.excerpt}</p>
                <button
                  onClick={() => setActiveNewsItem(item.id)}
                  className="mt-3 text-purple-700 font-medium hover:text-purple-900 transition-colors"
                >
                  Read more
                </button>
              </div>
            </div>
          ))}
        </div>
        
        {/* Modal for full news content */}
        {activeNewsItem !== null && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              {news
                .filter(item => item.id === activeNewsItem)
                .map(item => (
                  <div key={item.id}>
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-full h-64 object-cover"
                    />
                    <div className="p-6">
                      <h3 className="font-bold text-2xl text-purple-900">{item.title}</h3>
                      <div className="flex items-center mt-2 text-gray-500 mb-4">
                        <Calendar size={16} className="mr-2" />
                        <span>{formatDate(item.date)}</span>
                        <span className="mx-2">•</span>
                        <span>By {item.author}</span>
                      </div>
                      <div className="text-gray-700 leading-relaxed space-y-4">
                        <p>{item.content}</p>
                      </div>
                      <button
                        onClick={() => setActiveNewsItem(null)}
                        className="mt-6 px-4 py-2 bg-purple-700 text-white rounded-md hover:bg-purple-800 transition-colors"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default News;