import React from 'react';
import { MailPlus } from 'lucide-react';

const Newsletter: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-purple-900 to-pink-600 rounded-lg shadow-lg p-8 text-white">
      <div className="max-w-3xl mx-auto text-center">
        <MailPlus size={48} className="mx-auto mb-4" />
        <h2 className="text-2xl md:text-3xl font-bold mb-3">Subscribe to Our Newsletter</h2>
        <p className="mb-6 opacity-90">Get the latest updates, exclusive content, and special offers directly to your inbox!</p>
        
        <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
          <input
            type="email"
            placeholder="Your email address"
            className="flex-grow px-4 py-3 rounded-md bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50"
            required
          />
          <button
            type="submit"
            className="px-6 py-3 bg-white text-purple-900 font-bold rounded-md hover:bg-purple-100 transition-colors"
          >
            Subscribe
          </button>
        </form>
        
        <p className="mt-4 text-sm opacity-75">We respect your privacy.</p>
      </div>
    </div>
  );
};

export default Newsletter;